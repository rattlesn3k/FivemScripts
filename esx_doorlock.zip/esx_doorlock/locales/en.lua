Locales ['en'] = {
	['unlocked'] = '~g~Open~s~',
	['locked'] = '~r~Op Slot~s~',
	['press_button'] = '[E] %s',
}
