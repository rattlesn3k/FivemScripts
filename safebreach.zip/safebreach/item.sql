INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES
	('champagne', 'Champagne Bottle', -1, 0, 1)
;