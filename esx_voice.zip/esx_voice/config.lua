Config        = {}
Config.Locale = 'pl'