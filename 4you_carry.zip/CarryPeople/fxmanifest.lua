-- Resource Metadata
fx_version 'bodacious'
games { 'gta5' }

author 'rubbertoe98'
description 'CarryPeople'
version '1.0.0'

client_script "cl_carry.lua"
server_script "sv_carry.lua"
