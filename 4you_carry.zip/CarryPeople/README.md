# Carry People by Robbster

Instructions on how to use:
Type /carry close to someone then either person can cancel by again doing /carry

Feel free to make improvements with PRs
