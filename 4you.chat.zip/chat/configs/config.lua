Config = {}

Config.Locale = 'ks'
Config.OnlyFirstname = false
Config.EnableESXIdentity = true