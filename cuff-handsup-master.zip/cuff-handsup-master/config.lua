CuffHandsConfig = {}

CuffHandsConfig.UseRestriction = false
CuffHandsConfig.AllowedUsers = {}