-- vRP Tunnel/Proxy
local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP")

local userlogin = {}
-- Resource Tunnel/Proxy
vRPcr = {}
Tunnel.bindInterface("nui_personagem",vRPcr)
Proxy.addInterface("nui_personagem",vRPcr)
CRclient = Tunnel.getInterface("nui_personagem")

AddEventHandler("vRP:playerSpawn",function(user_id,source,first_spawn)
	if first_spawn then
		local data = vRP.getUData(user_id,"vRP:spawnController")
		local spawnStatus = json.decode(data) or 0
		SetTimeout(5000, function() -- tunnel/proxy delay
			processSpawnController(source, spawnStatus, user_id)
		end)
	end
end)

function processSpawnController(source,statusSent,user_id)
	local source = source
	if statusSent == 2 then
		if not userlogin[user_id] then
			userlogin[user_id] = true
			doSpawnPlayer(source,user_id,false)
		else
			doSpawnPlayer(source,user_id,true)
		end
	elseif statusSent == 1 or statusSent == 0 then
		userlogin[user_id] = true
		TriggerClientEvent('skinCreator:abrirCriacao', source)
    end
    local custom = vRP.getUData(user_id,"currentCharacterMode")
    local lcustom = json.decode(custom)
    if custom then
        CRclient.setOverlay(source, lcustom)
    end
end

RegisterNetEvent('skinCreator:criarIndentidade')
AddEventHandler('skinCreator:criarIndentidade', function(data, custom)
    local source = source
    local user_id = vRP.getUserId(source)
    if data then
        local nome = data.nome
        local foto = data.foto
        local sobrenome = data.sobrenome
        local idade = data.idade
        local registration = vRP.generateRegistrationNumber()
        local phone = vRP.generatePhoneNumber()
        vRP.setUData(user_id,"currentCharacterMode", json.encode(custom))
        vRP.setUData(user_id,"vRP:spawnController", json.encode(2))
        vRP.execute("vRP/update_user_identity", {
            ['user_id'] = user_id,
            ['age'] = idade,
            ['name'] = nome,
            ['firstname'] = sobrenome,
            ['registration'] = registration,
            ['phone'] = phone,
            ['foto'] = "http://painelcontabil.com.br/contador/painel/img/login.png"
        })
        print("finishedCharacter")
		doSpawnPlayer(source,user_id,true)
        vRPclient.setRegistrationNumber(source,registration)
    end
end)

function doSpawnPlayer(source,user_id,firstspawn)
	TriggerClientEvent("SkinCreator:normalSpawn",source,firstspawn)
end